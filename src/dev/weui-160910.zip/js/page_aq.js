/* global $ */
/* global FastClick */
/* global document */

$(function(){
    FastClick.attach(document.body);
});